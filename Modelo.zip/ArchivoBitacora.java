package Modelo;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author jceba
 */
public class ArchivoBitacora{
    /**
     * Escribe en el archivo de bitacora
     * @param bitacora objeto de registro
     * @param ruta ruta del archivo que lleva la bitacora
     * @throws IOException 
     */
    public void EscribirBitacora(Bitacora bitacora, String ruta) throws IOException{
        BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta, true));
        escritor.write(bitacora.toString());
        escritor.newLine();
    }
    
}
