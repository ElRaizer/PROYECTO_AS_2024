package Modelo;

/**
 *
 * @author jceba
 */
public class Bitacora {
    private String hora;
    private String nombreArticulo;

    public Bitacora(String hora, String nombreArticulo) {
        this.hora = hora;
        this.nombreArticulo = nombreArticulo;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getNombreArticulo() {
        return nombreArticulo;
    }

    public void setNombreArticulo(String nombreArticulo) {
        this.nombreArticulo = nombreArticulo;
    }

    @Override
    public String toString() {
        return nombreArticulo + "\t\t\t\t" + hora + "\t\t";
    }
    
    
}
