package Modelo;

import java.io.IOException;
import java.util.List;

/**
 *
 * @author jceba
 */
public class Votacion {
    private List<Articulo> conjunto;
    private int votosTotales = 0;
    private final int numArticulos = 3;

    public Votacion() throws IOException {
        ArchivoVotacion archivos = new ArchivoVotacion();
        if(archivos.getConjunto().size() == this.numArticulos){
            if(!archivos.ValidarArticulos()){
                archivos.ReiniciarArchivoVotos();
            }
            conjunto = archivos.getConjunto();
            for(Articulo articulo:conjunto){
                this.votosTotales += articulo.getConteoVotos();
            }
        }else{
            System.out.println("Tamaño de artículos para la votación inadecuado (" + this.numArticulos + ")");
        }
    }

    public List<Articulo> getConjunto() {
        return conjunto;
    }

    public void setConjunto(List<Articulo> conjunto) {
        this.conjunto = conjunto;
    }
    
    /**
     * Lee el voto y lo contabiliza a su respectivo objeto articulo
     * @param voto número del articulo que contabilizara un voto
     */
    public void ContabilizarVoto(int voto){
        this.conjunto.get(voto).aumentoConteo();
        this.votosTotales++;
    }
}
