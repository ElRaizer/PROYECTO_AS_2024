package Modelo;

/**
 *
 * @author jceba
 */
public class Articulo {
    private String nombre;
    private int conteoVotos;

    public Articulo(String nombre, int conteoVotos) {
        this.nombre = nombre;
        this.conteoVotos = conteoVotos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getConteoVotos() {
        return conteoVotos;
    }

    public void setConteoVotos(int conteoVotos) {
        this.conteoVotos = conteoVotos;
    }
 
    /**
     * Suma en 1 el total de votos del artículo
     */
    public void aumentoConteo(){
        this.conteoVotos++;
    }

    @Override
    public String toString() {
        return nombre + "-" + conteoVotos;
    }
    
    
}
