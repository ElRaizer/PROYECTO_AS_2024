package Modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jceba
 */
public final class ArchivoVotacion {
    private List<Articulo> conjunto = new ArrayList<>();
    private List<String> validacion = new ArrayList<>();
    
    public ArchivoVotacion() throws IOException {
        LeerArticulosVotos("Articulos_recientes.txt");
        LeerArchivoValidacion("/Articulos_votacion.txt");
    }

    public List<Articulo> getConjunto() {
        return conjunto;
    }

    public void setConjunto(List<Articulo> conjunto) {
        this.conjunto = conjunto;
    }

    public List<String> getValidacion() {
        return validacion;
    }

    public void setValidacion(List<String> validacion) {
        this.validacion = validacion;
    }
    
    /**
     * Lee archivo de estructura votación
     * @param ruta
     * @throws IOException 
     */
    private void LeerArticulosVotos(String ruta) throws IOException{
        BufferedReader br = new BufferedReader(new FileReader(ruta));
        String linea;
        
        try {
            while ((linea = br.readLine()) != null) {
                List<String> nombre_conteo = List.of(linea.split("-"));
                Articulo articulo = new Articulo(nombre_conteo.get(0), Integer.parseInt(nombre_conteo.get(1)));
                this.conjunto.add(articulo);
            }
        } catch (IndexOutOfBoundsException e) {
            System.out.println("Archivo " + ruta + " mal estructurado");
        }
    }
    
    /**
     * Lee archivo de validación de articulos
     * @param ruta
     * @throws IOException 
     */
    private void LeerArchivoValidacion(String ruta) throws IOException{
        BufferedReader br = new BufferedReader(new FileReader(ruta) );
        String linea;
        while((linea = br.readLine()) != null){
            this.validacion.add(linea);
        }
    }
    
    /**
     * Reescribe el archivo de votación
     * @param ruta
     * @throws IOException 
     */
    public void EscribirArchivo(String ruta) throws IOException{
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta, false))){
            for(Articulo linea : conjunto){
                escritor.write(linea.toString());
            }
        }
    }
    
    /**
     * Compara y valida que el archivo de articulos y de votación coincidan
     * @return devuelve verdadero si son iguales, si faltan o sobran elementos devuelve falso
     */
    public boolean ValidarArticulos(){
        List<Articulo> listaReferencia = conjunto;
        for(Articulo articulo:conjunto){
            for(String nombre:validacion){
                if(articulo.getNombre().equals(nombre)){
                    listaReferencia.remove(articulo);
                    validacion.remove(nombre);
                }
            }
        }
        return listaReferencia.isEmpty() && validacion.isEmpty();
    }
    
    /**
     * Reestablece el contador de votos a cero
     * @throws IOException 
     */
    public void ReiniciarArchivoVotos() throws IOException{
        for(int i=0; i<=this.conjunto.size(); i++){
            this.conjunto.get(i).setNombre(this.validacion.get(i));
            this.conjunto.get(i).setConteoVotos(0);
        }
        EscribirArchivo("Articulos_recientes.txt");
    }
    
}
