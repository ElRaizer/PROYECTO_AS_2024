/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CAPAS;

/**
 *
 * @author USER
 */
import java.util.*;

public class CapaFiltro {

    // Método para ordenar alfabéticamente las rotaciones
    public List<String> sortRotaciones(List<String> rotaciones) {
        Collections.sort(rotaciones);
        return rotaciones;
    }
}

